package com.example.packagefortracking

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            PackageTrackingApp()
        }
    }
}

data class PackageItem(
    val name: String,
    val trackingNumber: String,
    val provider: String,
    val status: String,
    val estimatedDelivery: String,
    val lastUpdate: String,
    val lastLocation: String,
    val isDelivered: Boolean
)

@Composable
fun PackageTrackingApp() {
    MaterialTheme {
        HomeScreen()
    }
}

@Composable
fun HomeScreen() {
    val packages = listOf(
        PackageItem(
            "Gaming Mouse",
            "RB234567891BA",
            "BH Post",
            "In Transit",
            "12 Jun 2026",
            "Today, 14:20",
            "Sarajevo, BiH",
            false
        ),
        PackageItem(
            "Sneakers",
            "RA987654321BA",
            "HP Mostar",
            "Delivered",
            "Yesterday, 10:15",
            "Yesterday, 10:15",
            "Sarajevo, BiH",
            true
        ),
        PackageItem(
            "Textbook",
            "RQ123456789BA",
            "Pošta Srpske",
            "In Transit",
            "15 Jun 2026",
            "Yesterday, 18:45",
            "Banja Luka, BiH",
            false
        )
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF8FAFF))
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(bottom = 105.dp),
            contentPadding = PaddingValues(20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item { HeaderSection() }
            item { SearchSection() }
            item { FilterTabs() }
            item { StatsCard() }

            items(packages) { item ->
                PackageCard(item)
            }
        }

        FloatingActionButton(
            onClick = {},
            containerColor = Color(0xFFFFC107),
            contentColor = Color(0xFF001B4D),
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(end = 22.dp, bottom = 92.dp)
                .size(64.dp)
        ) {
            Icon(
                imageVector = Icons.Default.Add,
                contentDescription = "Add Package",
                modifier = Modifier.size(34.dp)
            )
        }

        BottomNavBar(
            modifier = Modifier.align(Alignment.BottomCenter)
        )
    }
}

@Composable
fun HeaderSection() {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(150.dp)
    ) {
        Box(
            modifier = Modifier
                .size(160.dp)
                .align(Alignment.TopEnd)
                .offset(x = 45.dp, y = (-55).dp)
                .background(
                    brush = Brush.radialGradient(
                        colors = listOf(
                            Color(0xFFFFE58A),
                            Color(0xFFFFF5CC),
                            Color.Transparent
                        )
                    ),
                    shape = CircleShape
                )
        )

        Column(
            modifier = Modifier.align(Alignment.BottomStart)
        ) {
            Text(
                text = "My Packages",
                fontSize = 40.sp,
                fontWeight = FontWeight.ExtraBold,
                color = Color(0xFF001B4D)
            )

            Text(
                text = "Track and manage your shipments",
                fontSize = 17.sp,
                color = Color(0xFF6B7280),
                modifier = Modifier.padding(top = 4.dp)
            )
        }

        Box(
            modifier = Modifier
                .align(Alignment.CenterEnd)
                .padding(top = 40.dp)
        ) {
            Icon(
                imageVector = Icons.Default.NotificationsNone,
                contentDescription = "Notifications",
                tint = Color(0xFF001B4D),
                modifier = Modifier.size(34.dp)
            )

            Box(
                modifier = Modifier
                    .size(23.dp)
                    .align(Alignment.TopEnd)
                    .offset(x = 6.dp, y = (-8).dp)
                    .background(Color(0xFFFFC107), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "3",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF001B4D)
                )
            }
        }
    }
}

@Composable
fun SearchSection() {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(
            modifier = Modifier
                .weight(1f)
                .height(64.dp)
                .shadowCard()
                .background(Color.White, RoundedCornerShape(16.dp))
                .padding(horizontal = 18.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Default.Search,
                contentDescription = null,
                tint = Color(0xFF001B4D),
                modifier = Modifier.size(30.dp)
            )

            Spacer(modifier = Modifier.width(14.dp))

            Text(
                text = "Search by name or tracking number...",
                color = Color(0xFF7A8194),
                fontSize = 15.sp,
                maxLines = 1
            )
        }

        Box(
            modifier = Modifier
                .size(64.dp)
                .shadowCard()
                .background(Color.White, RoundedCornerShape(16.dp)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Default.Tune,
                contentDescription = "Filter",
                tint = Color(0xFF001B4D),
                modifier = Modifier.size(28.dp)
            )
        }
    }
}

@Composable
fun FilterTabs() {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        FilterButton("All (12)", Icons.Default.GridView, true, Modifier.weight(1f))
        FilterButton("In Transit (5)", Icons.Default.LocalShipping, false, Modifier.weight(1.25f))
        FilterButton("Delivered (7)", Icons.Default.CheckCircleOutline, false, Modifier.weight(1.25f))
        FilterButton("Archived (0)", Icons.Default.Inventory2, false, Modifier.weight(1.25f))
    }
}

@Composable
fun FilterButton(
    text: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    selected: Boolean,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .height(52.dp)
            .shadowCard()
            .background(
                color = if (selected) Color(0xFFFFC107) else Color.White,
                shape = RoundedCornerShape(14.dp)
            )
            .padding(horizontal = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = Color(0xFF001B4D),
            modifier = Modifier.size(22.dp)
        )

        Spacer(modifier = Modifier.width(6.dp))

        Text(
            text = text,
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFF001B4D),
            maxLines = 1
        )
    }
}

@Composable
fun StatsCard() {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .shadowCard()
            .background(Color.White, RoundedCornerShape(22.dp))
            .padding(vertical = 22.dp),
        horizontalArrangement = Arrangement.SpaceEvenly
    ) {
        StatItem(Icons.Default.Inventory2, "Total Packages", "12", Color(0xFFFFB300))
        DividerVertical()
        StatItem(Icons.Default.LocalShipping, "In Transit", "5", Color(0xFF1976D2))
        DividerVertical()
        StatItem(Icons.Default.CheckCircleOutline, "Delivered", "7", Color(0xFF10B981))
        DividerVertical()
        StatItem(Icons.Default.Archive, "Archived", "0", Color(0xFF9CA3AF))
    }
}

@Composable
fun StatItem(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    value: String,
    color: Color
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.width(78.dp)
    ) {
        Box(
            modifier = Modifier
                .size(54.dp)
                .background(color.copy(alpha = 0.14f), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = color,
                modifier = Modifier.size(28.dp)
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        Text(
            text = label,
            fontSize = 12.sp,
            color = Color(0xFF4B5563),
            textAlign = TextAlign.Center,
            maxLines = 2
        )

        Text(
            text = value,
            fontSize = 26.sp,
            fontWeight = FontWeight.ExtraBold,
            color = Color(0xFF001B4D),
            modifier = Modifier.padding(top = 4.dp)
        )

        Box(
            modifier = Modifier
                .width(28.dp)
                .height(4.dp)
                .background(color, RoundedCornerShape(8.dp))
        )
    }
}

@Composable
fun DividerVertical() {
    Box(
        modifier = Modifier
            .height(115.dp)
            .width(1.dp)
            .background(Color(0xFFE5E7EB))
    )
}

@Composable
fun PackageCard(item: PackageItem) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .shadowCard()
            .background(Color.White, RoundedCornerShape(22.dp))
            .padding(16.dp)
    ) {
        Row(
            verticalAlignment = Alignment.Top
        ) {
            ProviderLogo(item.provider)

            Spacer(modifier = Modifier.width(14.dp))

            Column(
                modifier = Modifier.weight(1f)
            ) {
                Text(
                    text = item.name,
                    fontSize = 21.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = Color(0xFF001B4D)
                )

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = item.trackingNumber,
                        fontSize = 14.sp,
                        color = Color(0xFF6B7280)
                    )

                    Spacer(modifier = Modifier.width(6.dp))

                    Icon(
                        imageVector = Icons.Default.ContentCopy,
                        contentDescription = null,
                        tint = Color(0xFF6B7280),
                        modifier = Modifier.size(15.dp)
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                ProviderChip(item.provider)
            }

            Column(
                horizontalAlignment = Alignment.End
            ) {
                StatusChip(item.status, item.isDelivered)

                Spacer(modifier = Modifier.height(10.dp))

                Text(
                    text = if (item.isDelivered) "Delivered on" else "Estimated delivery",
                    fontSize = 12.sp,
                    color = Color(0xFF6B7280)
                )

                Text(
                    text = item.estimatedDelivery,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF001B4D)
                )
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        if (!item.isDelivered) {
            ProgressLine()
            Spacer(modifier = Modifier.height(16.dp))
        }

        Divider(color = Color(0xFFE5E7EB))

        Spacer(modifier = Modifier.height(14.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            InfoBlock(
                icon = Icons.Default.CalendarMonth,
                title = "Last update",
                value = item.lastUpdate,
                color = Color(0xFFFFB300),
                modifier = Modifier.weight(1f)
            )

            Box(
                modifier = Modifier
                    .height(42.dp)
                    .width(1.dp)
                    .background(Color(0xFFE5E7EB))
            )

            InfoBlock(
                icon = Icons.Default.LocationOn,
                title = if (item.isDelivered) "Delivered to" else "Last location",
                value = item.lastLocation,
                color = Color(0xFF64748B),
                modifier = Modifier.weight(1f)
            )

            Spacer(modifier = Modifier.width(10.dp))

            Button(
                onClick = {},
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFFFFF3C4),
                    contentColor = Color(0xFF001B4D)
                ),
                shape = RoundedCornerShape(12.dp),
                contentPadding = PaddingValues(horizontal = 14.dp, vertical = 10.dp)
            ) {
                Text(
                    text = "View Details",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.width(4.dp))
                Icon(
                    imageVector = Icons.Default.ChevronRight,
                    contentDescription = null,
                    modifier = Modifier.size(18.dp)
                )
            }
        }
    }
}

@Composable
fun ProviderLogo(provider: String) {
    val text = when (provider) {
        "BH Post" -> "BH\nPOŠTA"
        "HP Mostar" -> "HP\nMOSTAR"
        else -> "ПОШТЕ\nСРПСКЕ"
    }

    val color = when (provider) {
        "BH Post" -> Color(0xFF0057B8)
        "HP Mostar" -> Color(0xFFE31B23)
        else -> Color(0xFF0057B8)
    }

    Box(
        modifier = Modifier
            .size(86.dp)
            .background(Color.White, RoundedCornerShape(14.dp))
            .border(1.dp, Color(0xFFE5E7EB), RoundedCornerShape(14.dp)),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = text,
            color = color,
            fontSize = 16.sp,
            fontWeight = FontWeight.ExtraBold,
            textAlign = TextAlign.Center,
            lineHeight = 17.sp
        )
    }
}

@Composable
fun ProviderChip(provider: String) {
    val bg = when (provider) {
        "BH Post" -> Color(0xFFFFF3C4)
        "HP Mostar" -> Color(0xFFFFE3E3)
        else -> Color(0xFFE3F2FF)
    }

    val textColor = when (provider) {
        "BH Post" -> Color(0xFF001B4D)
        "HP Mostar" -> Color(0xFF8B1A1A)
        else -> Color(0xFF0057B8)
    }

    Text(
        text = provider,
        fontSize = 13.sp,
        fontWeight = FontWeight.Bold,
        color = textColor,
        modifier = Modifier
            .background(bg, RoundedCornerShape(8.dp))
            .padding(horizontal = 10.dp, vertical = 5.dp)
    )
}

@Composable
fun StatusChip(status: String, delivered: Boolean) {
    val bg = if (delivered) Color(0xFFDFF7E8) else Color(0xFFFFF3C4)
    val color = if (delivered) Color(0xFF10B981) else Color(0xFFFFB300)

    Row(
        modifier = Modifier
            .background(bg, RoundedCornerShape(10.dp))
            .padding(horizontal = 10.dp, vertical = 7.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(9.dp)
                .background(color, CircleShape)
        )

        Spacer(modifier = Modifier.width(6.dp))

        Text(
            text = status,
            color = color,
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold
        )
    }
}

@Composable
fun ProgressLine() {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        ProgressStep("Accepted", Icons.Default.Inventory2, true)
        ProgressConnector(true, Modifier.weight(1f))
        ProgressStep("In Transit", Icons.Default.LocalShipping, true)
        ProgressConnector(false, Modifier.weight(1f))
        ProgressStep("Out for Delivery", Icons.Default.LocalShipping, false)
        ProgressConnector(false, Modifier.weight(1f))
        ProgressStep("Delivered", Icons.Default.Check, false)
    }
}

@Composable
fun ProgressStep(
    label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    active: Boolean
) {
    val color = if (active) Color(0xFFFFB300) else Color(0xFFCBD5E1)

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.width(78.dp)
    ) {
        Box(
            modifier = Modifier
                .size(26.dp)
                .background(color, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = Color.White,
                modifier = Modifier.size(15.dp)
            )
        }

        Spacer(modifier = Modifier.height(6.dp))

        Text(
            text = label,
            fontSize = 10.sp,
            color = color,
            fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Center,
            maxLines = 2
        )
    }
}

@Composable
fun ProgressConnector(
    active: Boolean,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .height(2.dp)
            .background(
                if (active) Color(0xFFFFB300) else Color(0xFFCBD5E1),
                RoundedCornerShape(4.dp)
            )
    )
}

@Composable
fun InfoBlock(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    value: String,
    color: Color,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier.padding(horizontal = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = color,
            modifier = Modifier.size(28.dp)
        )

        Spacer(modifier = Modifier.width(8.dp))

        Column {
            Text(
                text = title,
                fontSize = 11.sp,
                color = Color(0xFF6B7280)
            )

            Text(
                text = value,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF001B4D),
                maxLines = 2
            )
        }
    }
}

@Composable
fun BottomNavBar(modifier: Modifier = Modifier) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .height(86.dp)
            .background(Color.White)
            .padding(horizontal = 36.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        BottomItem(Icons.Default.Home, "Home", true)
        BottomItem(Icons.Default.NotificationsNone, "Notifications", false)
        BottomItem(Icons.Default.Settings, "Settings", false)
    }
}

@Composable
fun BottomItem(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    selected: Boolean
) {
    val color = if (selected) Color(0xFFFFB300) else Color(0xFF001B4D)

    Column(
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(
            imageVector = icon,
            contentDescription = label,
            tint = color,
            modifier = Modifier.size(28.dp)
        )

        Spacer(modifier = Modifier.height(4.dp))

        Text(
            text = label,
            fontSize = 12.sp,
            color = color,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal
        )

        if (selected) {
            Spacer(modifier = Modifier.height(4.dp))

            Box(
                modifier = Modifier
                    .width(28.dp)
                    .height(4.dp)
                    .background(color, RoundedCornerShape(8.dp))
            )
        }
    }
}

fun Modifier.shadowCard() =
    this.shadow(
        elevation = 8.dp,
        shape = RoundedCornerShape(18.dp)
    )
}